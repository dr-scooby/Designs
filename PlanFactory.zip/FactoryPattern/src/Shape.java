// interface that all classes will implement
public interface Shape {
	
	void draw();

}
