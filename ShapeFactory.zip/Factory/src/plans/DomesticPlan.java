/**
 * 
 */
package plans;

/**
 * @author jismailx
 *
 */
public class DomesticPlan extends Plan {

	
	@Override
	public 	void getRate() {
		// TODO Auto-generated method stub
		rate = 3.50;
	}

	
}
