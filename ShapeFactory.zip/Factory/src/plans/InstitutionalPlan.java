/**
 * 
 */
package plans;

/**
 * @author jismailx
 *
 */
public class InstitutionalPlan extends Plan{

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		rate = 5.50;
	}

}
