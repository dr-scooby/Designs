/**
 * 
 */
package plans;

/**
 * @author jismailx
 *
 */
public class CommercialPlan extends Plan{

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		rate = 7.50;
	}

	
}
